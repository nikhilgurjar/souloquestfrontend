export { default as SkeletonMap } from './SkeletonMap';
export { default as SkeletonPostItem } from './SkeletonPostItem';
export { default as SkeletonPostDetails } from './SkeletonPostDetails';
export { default as SkeletonProductItem } from './SkeletonProductItem';
export { default as SkeletonMailNavItem } from './SkeletonMailNavItem';
export { default as SkeletonKanbanColumn } from './SkeletonKanbanColumn';
export { default as SkeletonProductDetails } from './SkeletonProductDetails';
export { default as SkeletonConversationItem } from './SkeletonConversationItem';
